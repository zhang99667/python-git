def receive():
    return "这是来自 10010 的短信"